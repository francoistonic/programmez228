# coding: utf-8
import time
import serial

ser = serial.Serial('/dev/ttyUSB0', 9600)

while 1 :
  print(ser.readline())
  time.sleep(0.1)