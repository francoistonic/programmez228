// LMDBWindowsDll.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "..\Include\LMDBWindowsDll.h"


// This is an example of an exported function.
LMDBWINDOWSDLL_API int fnLMDBWindowsDll(void)
{
    return 42;
}
